<script setup lang="ts">
import { ref, computed } from 'vue'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import {
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Plus,
  Search,
  DollarSign,
  Wallet,
  Trash2
} from 'lucide-vue-next'
import VueApexCharts from 'vue3-apexcharts'
import Header from "@/components/kakangCustom/Header.vue"
import { useAuthStore } from "@/stores/auth.ts"
import type { DateRange } from "reka-ui"
import type { Ref } from "vue"
import {
  CalendarDate,
  DateFormatter,
  getLocalTimeZone,
} from "@internationalized/date"
import { CalendarIcon } from "lucide-vue-next"
import { cn } from "@/lib/utils"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { RangeCalendar } from "@/components/ui/range-calendar"
import { toast } from "vue-sonner"

// Date Picker Setup
const df = new DateFormatter("en-US", {
  dateStyle: "medium",
})

const value = ref({
  start: new CalendarDate(2024, 10, 1),
  end: new CalendarDate(2024, 10, 31),
}) as Ref<DateRange>

// Auth Store
const authStore = useAuthStore()

const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good Morning'
  if (hour < 18) return 'Good Afternoon'
  return 'Good Evening'
})

const userName = computed(() => {
  return authStore.userProfile?.displayName || authStore.user?.displayName || 'User'
})

// Format Currency Helper
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value)
}

// Cash Flow Summary
const cashFlowSummary = ref({
  openingBalance: 1650000000,
  totalInflow: 2450000000,
  totalOutflow: 1890000000,
  netCashFlow: 560000000,
  closingBalance: 2210000000,
  forecastedBalance: 2580000000
})

// Cash Flow Chart
const cashFlowChartOptions = ref({
  chart: {
    id: 'detailed-cash-flow',
    type: 'line',
    height: 400,
    toolbar: { show: true },
    fontFamily: 'inherit'
  },
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth', width: 3 },
  xaxis: {
    categories: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Forecast W1', 'Forecast W2', 'Forecast W3', 'Forecast W4']
  },
  colors: ['#3b82f6', '#10b981', '#ef4444'],
  legend: { position: 'top', horizontalAlign: 'right' },
  yaxis: {
    labels: {
      formatter: (val: number) => {
        if (val >= 1000000000) return `Rp ${(val / 1000000000).toFixed(1)}M`
        if (val >= 1000000) return `Rp ${(val / 1000000).toFixed(0)}jt`
        return `Rp ${(val / 1000).toFixed(0)}rb`
      }
    }
  },
  tooltip: {
    y: {
      formatter: (val: number) => formatCurrency(val)
    }
  },
  annotations: {
    xaxis: [{
      x: 4.5,
      borderColor: '#999',
      label: {
        text: 'Forecast',
        style: {
          color: '#fff',
          background: '#999'
        }
      }
    }]
  }
})

const cashFlowChartSeries = ref([
  {
    name: 'Cash Balance',
    data: [1650000000, 1780000000, 1920000000, 2210000000, 2350000000, 2480000000, 2520000000, 2580000000]
  },
  {
    name: 'Cash Inflow',
    data: [450000000, 520000000, 480000000, 650000000, 580000000, 620000000, 590000000, 610000000]
  },
  {
    name: 'Cash Outflow',
    data: [320000000, 380000000, 350000000, 360000000, 440000000, 490000000, 450000000, 470000000]
  }
])

// Cash Flow Transactions
const cashFlowTransactions = ref([
  { id: 'CF-2024-001', date: '2024-10-03', type: 'inflow', category: 'Sales Revenue', description: 'Payment from PT Maju Jaya - Invoice INV-2024-001', amount: 125000000, status: 'confirmed', reference: 'INV-2024-001' },
  { id: 'CF-2024-002', date: '2024-10-03', type: 'outflow', category: 'Salaries & Benefits', description: 'Monthly Salary Payment - October 2024', amount: 55000000, status: 'confirmed', reference: 'PAY-2024-010' },
  { id: 'CF-2024-003', date: '2024-10-02', type: 'inflow', category: 'Sales Revenue', description: 'Payment from CV Sukses Mandiri - Invoice INV-2024-002', amount: 85000000, status: 'confirmed', reference: 'INV-2024-002' },
  { id: 'CF-2024-004', date: '2024-10-02', type: 'outflow', category: 'Operating Expenses', description: 'Office Rent Payment - October 2024', amount: 15000000, status: 'confirmed', reference: 'RENT-2024-10' },
  { id: 'CF-2024-005', date: '2024-10-01', type: 'outflow', category: 'Operating Expenses', description: 'Marketing Campaign - Digital Advertising', amount: 12000000, status: 'confirmed', reference: 'MKT-2024-015' },
  { id: 'CF-2024-006', date: '2024-10-05', type: 'inflow', category: 'Sales Revenue', description: 'Expected payment from Toko Berkah', amount: 45000000, status: 'forecasted', reference: 'INV-2024-003' },
  { id: 'CF-2024-007', date: '2024-10-08', type: 'outflow', category: 'Loan Payments', description: 'Bank Loan Installment - October 2024', amount: 35000000, status: 'scheduled', reference: 'LOAN-2024-10' }
])

// Dialog states
const isAddTransactionOpen = ref(false)

// Form data
const newTransaction = ref({
  type: 'inflow',
  category: '',
  description: '',
  amount: 0,
  date: '',
  reference: '',
  status: 'scheduled'
})

// Search and filter
const searchQuery = ref('')
const selectedFilter = ref('all')

// Computed filtered transactions
const filteredTransactions = computed(() => {
  let filtered = cashFlowTransactions.value

  if (searchQuery.value) {
    filtered = filtered.filter(t => 
      t.description.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      t.reference.toLowerCase().includes(searchQuery.value.toLowerCase())
    )
  }

  if (selectedFilter.value !== 'all') {
    filtered = filtered.filter(t => t.type === selectedFilter.value)
  }

  return filtered
})

// Functions
const handleAddTransaction = () => {
  const transaction = {
    id: `CF-2024-${String(cashFlowTransactions.value.length + 1).padStart(3, '0')}`,
    ...newTransaction.value,
    date: newTransaction.value.date || new Date().toISOString().split('T')[0]
  }
  
  cashFlowTransactions.value.unshift(transaction)
  
  // Reset form
  newTransaction.value = {
    type: 'inflow',
    category: '',
    description: '',
    amount: 0,
    date: '',
    reference: '',
    status: 'scheduled'
  }
  
  isAddTransactionOpen.value = false
  toast.success('Cash flow transaction added successfully!')
}

const handleDeleteTransaction = (id: string) => {
  cashFlowTransactions.value = cashFlowTransactions.value.filter(t => t.id !== id)
  toast.success('Transaction deleted successfully!')
}

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    confirmed: 'bg-green-100 text-green-800',
    scheduled: 'bg-blue-100 text-blue-800',
    forecasted: 'bg-yellow-100 text-yellow-800',
    cancelled: 'bg-red-100 text-red-800'
  }
  return colors[status] || 'bg-gray-100 text-gray-800'
}

const getTransactionColor = (type: string) => {
  return type === 'inflow' ? 'text-green-600' : 'text-red-600'
}

const getTransactionIcon = (type: string) => {
  return type === 'inflow' ? ArrowDownRight : ArrowUpRight
}

const exportCashFlow = () => {
  const start = value.value?.start
  const end = value.value?.end ?? start

  if (!start) {
    toast.error('Please select a date range first.')
    return
  }

  const toastId = toast.loading('Preparing cash flow report...')

  setTimeout(() => {
    toast.success('Cash flow report exported successfully!', {
      id: toastId,
      duration: 3000
    })
  }, 1500)
}
</script>

<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <Header
          title="Cash Flow Management"
          :subtitle="`${greeting}, ${userName}!`"
          align="left"
      />

      <div class="flex items-center gap-2">
        <Popover>
          <PopoverTrigger as-child>
            <Button
                variant="outline"
                :class="cn(
                  'w-[280px] justify-start text-left font-normal',
                  !value && 'text-muted-foreground',
                )"
            >
              <CalendarIcon class="mr-2 h-4 w-4" />
              <template v-if="value.start">
                <template v-if="value.end">
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }} - {{ df.format(value.end.toDate(getLocalTimeZone())) }}
                </template>
                <template v-else>
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }}
                </template>
              </template>
              <template v-else>
                Pick a date range
              </template>
            </Button>
          </PopoverTrigger>
          <PopoverContent class="w-auto p-0">
            <RangeCalendar
                v-model="value"
                initial-focus
                :number-of-months="2"
                @update:start-value="(startDate) => value.start = startDate"
            />
          </PopoverContent>
        </Popover>

        <Button @click="exportCashFlow">
          <Download class="mr-2 h-4 w-4" />
          Export
        </Button>

        <Dialog v-model:open="isAddTransactionOpen">
          <DialogTrigger as-child>
            <Button>
              <Plus class="mr-2 h-4 w-4" />
              Add Transaction
            </Button>
          </DialogTrigger>
          <DialogContent class="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Cash Flow Transaction</DialogTitle>
              <DialogDescription>
                Add a new cash flow transaction to track inflows and outflows.
              </DialogDescription>
            </DialogHeader>
            <div class="space-y-4">
              <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                  <Label>Type</Label>
                  <Select v-model="newTransaction.type">
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inflow">Cash Inflow</SelectItem>
                      <SelectItem value="outflow">Cash Outflow</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div class="space-y-2">
                  <Label>Status</Label>
                  <Select v-model="newTransaction.status">
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="confirmed">Confirmed</SelectItem>
                      <SelectItem value="scheduled">Scheduled</SelectItem>
                      <SelectItem value="forecasted">Forecasted</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div class="space-y-2">
                <Label>Category</Label>
                <Input v-model="newTransaction.category" placeholder="e.g., Sales Revenue, Operating Expenses" />
              </div>
              <div class="space-y-2">
                <Label>Description</Label>
                <Textarea v-model="newTransaction.description" placeholder="Transaction description" />
              </div>
              <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                  <Label>Amount (IDR)</Label>
                  <Input v-model.number="newTransaction.amount" type="number" placeholder="0" />
                </div>
                <div class="space-y-2">
                  <Label>Date</Label>
                  <Input v-model="newTransaction.date" type="date" />
                </div>
              </div>
              <div class="space-y-2">
                <Label>Reference</Label>
                <Input v-model="newTransaction.reference" placeholder="Invoice/Reference number" />
              </div>
              <div class="flex justify-end gap-2">
                <Button variant="outline" @click="isAddTransactionOpen = false">Cancel</Button>
                <Button @click="handleAddTransaction">Add Transaction</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>

    <!-- Cash Flow Summary Cards -->
    <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Opening Balance</CardTitle>
          <Wallet class="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold">{{ formatCurrency(cashFlowSummary.openingBalance) }}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Total Inflow</CardTitle>
          <ArrowDownRight class="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold text-green-600">{{ formatCurrency(cashFlowSummary.totalInflow) }}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Total Outflow</CardTitle>
          <ArrowUpRight class="h-4 w-4 text-red-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold text-red-600">{{ formatCurrency(cashFlowSummary.totalOutflow) }}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Net Cash Flow</CardTitle>
          <TrendingUp class="h-4 w-4 text-purple-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold text-purple-600">{{ formatCurrency(cashFlowSummary.netCashFlow) }}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Closing Balance</CardTitle>
          <DollarSign class="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold">{{ formatCurrency(cashFlowSummary.closingBalance) }}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">Forecasted Balance</CardTitle>
          <TrendingUp class="h-4 w-4 text-orange-600" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold text-orange-600">{{ formatCurrency(cashFlowSummary.forecastedBalance) }}</div>
        </CardContent>
      </Card>
    </div>

    <!-- Cash Flow Chart -->
    <Card>
      <CardHeader>
        <CardTitle>Cash Flow Trend & Forecast</CardTitle>
        <CardDescription>Weekly cash flow analysis with 4-week forecast</CardDescription>
      </CardHeader>
      <CardContent>
        <VueApexCharts
            type="line"
            height="400"
            :options="cashFlowChartOptions"
            :series="cashFlowChartSeries"
        />
      </CardContent>
    </Card>

    <!-- Cash Flow Transactions -->
    <Card>
      <CardHeader>
        <div class="flex items-center justify-between">
          <div>
            <CardTitle>Cash Flow Transactions</CardTitle>
            <CardDescription>Detailed list of all cash flow transactions</CardDescription>
          </div>
          <div class="flex items-center gap-2">
            <div class="relative">
              <Search class="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                  v-model="searchQuery"
                  placeholder="Search transactions..."
                  class="pl-8 w-64"
              />
            </div>
            <Select v-model="selectedFilter">
              <SelectTrigger class="w-32">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="inflow">Inflow</SelectItem>
                <SelectItem value="outflow">Outflow</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div class="space-y-3">
          <div
              v-for="transaction in filteredTransactions"
              :key="transaction.id"
              class="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors"
          >
            <div class="flex items-center gap-4 flex-1">
              <div :class="[
                transaction.type === 'inflow' ? 'bg-green-50' : 'bg-red-50',
                'p-2 rounded-lg'
              ]">
                <component
                    :is="getTransactionIcon(transaction.type)"
                    :class="[getTransactionColor(transaction.type), 'w-5 h-5']"
                />
              </div>
              <div class="flex-1">
                <div class="flex items-center gap-2 mb-1">
                  <p class="font-medium">{{ transaction.description }}</p>
                  <Badge :class="getStatusColor(transaction.status)" class="text-xs">
                    {{ transaction.status }}
                  </Badge>
                </div>
                <div class="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>{{ transaction.id }}</span>
                  <span>•</span>
                  <span>{{ transaction.date }}</span>
                  <span>•</span>
                  <Badge variant="outline" class="text-xs">{{ transaction.category }}</Badge>
                  <span v-if="transaction.reference">•</span>
                  <span v-if="transaction.reference" class="text-xs">{{ transaction.reference }}</span>
                </div>
              </div>
            </div>
            <div class="flex items-center gap-4">
              <div class="text-right">
                <p :class="[
                  'font-semibold text-lg',
                  getTransactionColor(transaction.type)
                ]">
                  {{ transaction.type === 'inflow' ? '+' : '-' }}{{ formatCurrency(transaction.amount) }}
                </p>
              </div>
              <div class="flex items-center gap-1">
                <Button variant="ghost" size="sm" @click="handleDeleteTransaction(transaction.id)">
                  <Trash2 class="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
</template>

<style scoped>

</style>
