<script setup lang="ts">
import { ref, computed } from 'vue'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Wallet,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  AlertCircle,
  Clock,
  Building2,
  Users2
} from 'lucide-vue-next'
import VueApexCharts from 'vue3-apexcharts'
import Header from "@/components/kakangCustom/Header.vue"
import { useAuthStore } from "@/stores/auth.ts"
import type { DateRange } from "reka-ui"
import type { Ref } from "vue"
import {
  CalendarDate,
  DateFormatter,
  getLocalTimeZone,
} from "@internationalized/date"
import { CalendarIcon } from "lucide-vue-next"
import { cn } from "@/lib/utils"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { RangeCalendar } from "@/components/ui/range-calendar"
import { toast } from "vue-sonner"

// Date Picker Setup
const df = new DateFormatter("en-US", {
  dateStyle: "medium",
})

const value = ref({
  start: new CalendarDate(2024, 10, 1),
  end: new CalendarDate(2024, 10, 3),
}) as Ref<DateRange>

// Auth Store
const authStore = useAuthStore()

const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good Morning'
  if (hour < 18) return 'Good Afternoon'
  return 'Good Evening'
})

const userName = computed(() => {
  return authStore.userProfile?.displayName || authStore.user?.displayName || 'User'
})

// Format Currency Helper
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value)
}

// Download Report Function
const handleDownloadReport = () => {
  const start = value.value?.start
  const end = value.value?.end ?? start

  if (!start) {
    toast.error('Please pick a start date first.')
    return
  }

  const toastId = toast.loading('Preparing financial report...')

  setTimeout(() => {
    toast.success('Financial report downloaded successfully!', {
      id: toastId,
      duration: 3000
    })

    console.log('Downloading financial report for:', {
      start: start.toString(),
      end: end?.toString(),
    })
  }, 1500)
}

// Financial KPI Data
const financialKpis = ref([
  {
    title: 'Total Cash Balance',
    value: 1850000000,
    change: '+18.2%',
    trend: 'up',
    icon: Wallet,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    title: 'Accounts Receivable',
    value: 456000000,
    change: '+5.3%',
    trend: 'up',
    icon: DollarSign,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    title: 'Accounts Payable',
    value: 289000000,
    change: '-12.1%',
    trend: 'down',
    icon: CreditCard,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50'
  },
  {
    title: 'Net Profit Margin',
    value: 28.5,
    change: '+3.2%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    isPercentage: true
  }
])

// Cash Flow Chart
const cashFlowOptions = ref({
  chart: {
    id: 'cash-flow-chart',
    type: 'area',
    height: 350,
    toolbar: { show: false },
    fontFamily: 'inherit'
  },
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth', width: 2 },
  xaxis: {
    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  },
  colors: ['#10b981', '#ef4444', '#3b82f6'],
  fill: {
    type: 'gradient',
    gradient: {
      shadeIntensity: 1,
      opacityFrom: 0.4,
      opacityTo: 0.1,
    }
  },
  legend: { position: 'top', horizontalAlign: 'right' },
  yaxis: {
    labels: {
      formatter: (val: number) => {
        if (val >= 1000000000) return `Rp ${(val / 1000000000).toFixed(1)}M`
        if (val >= 1000000) return `Rp ${(val / 1000000).toFixed(0)}jt`
        return `Rp ${(val / 1000).toFixed(0)}rb`
      }
    }
  },
  tooltip: {
    y: {
      formatter: (val: number) => formatCurrency(val)
    }
  }
})

const cashFlowSeries = ref([
  {
    name: 'Cash Inflow',
    data: [125000000, 138000000, 142000000, 155000000, 148000000, 165000000, 178000000, 172000000, 185000000, 195000000, 188000000, 205000000]
  },
  {
    name: 'Cash Outflow',
    data: [95000000, 102000000, 98000000, 115000000, 108000000, 122000000, 135000000, 128000000, 138000000, 145000000, 142000000, 155000000]
  },
  {
    name: 'Net Cash Flow',
    data: [30000000, 36000000, 44000000, 40000000, 40000000, 43000000, 43000000, 44000000, 47000000, 50000000, 46000000, 50000000]
  }
])

// Expense Breakdown Chart
const expenseBreakdownOptions = ref({
  chart: {
    type: 'donut',
    height: 320,
    fontFamily: 'inherit'
  },
  labels: ['Operational', 'Salaries', 'Marketing', 'R&D', 'Utilities', 'Others'],
  colors: ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6b7280'],
  legend: { position: 'bottom' },
  dataLabels: { enabled: true },
  plotOptions: {
    pie: {
      donut: {
        size: '70%',
        labels: {
          show: true,
          total: {
            show: true,
            label: 'Total Expenses',
            formatter: () => 'Rp 155jt'
          }
        }
      }
    }
  },
  tooltip: {
    y: {
      formatter: (val: number) => formatCurrency(val)
    }
  }
})

const expenseBreakdownSeries = ref([45000000, 55000000, 25000000, 15000000, 10000000, 5000000])

// Revenue vs Expense Chart
const revenueExpenseOptions = ref({
  chart: {
    type: 'bar',
    height: 320,
    toolbar: { show: false },
    fontFamily: 'inherit'
  },
  plotOptions: {
    bar: {
      horizontal: false,
      columnWidth: '55%',
      borderRadius: 4
    }
  },
  dataLabels: { enabled: false },
  stroke: { show: true, width: 2, colors: ['transparent'] },
  xaxis: {
    categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  },
  colors: ['#10b981', '#ef4444'],
  fill: { opacity: 1 },
  legend: { position: 'top', horizontalAlign: 'right' },
  yaxis: {
    labels: {
      formatter: (val: number) => {
        if (val >= 1000000000) return `${(val / 1000000000).toFixed(1)}M`
        if (val >= 1000000) return `${(val / 1000000).toFixed(0)}jt`
        return `${(val / 1000).toFixed(0)}rb`
      }
    }
  },
  tooltip: {
    y: {
      formatter: (val: number) => formatCurrency(val)
    }
  }
})

const revenueExpenseSeries = ref([
  {
    name: 'Revenue',
    data: [125000000, 138000000, 142000000, 155000000, 148000000, 165000000, 178000000, 172000000, 185000000, 195000000, 188000000, 205000000]
  },
  {
    name: 'Expenses',
    data: [95000000, 102000000, 98000000, 115000000, 108000000, 122000000, 135000000, 128000000, 138000000, 145000000, 142000000, 155000000]
  }
])

// Accounts Receivable
const accountsReceivable = ref([
  { customer: 'PT Maju Jaya', invoice: 'INV-2024-001', amount: 125000000, dueDate: '2024-10-10', status: 'overdue', days: 5 },
  { customer: 'CV Sukses Mandiri', invoice: 'INV-2024-002', amount: 85000000, dueDate: '2024-10-15', status: 'pending', days: 12 },
  { customer: 'Toko Berkah', invoice: 'INV-2024-003', amount: 45000000, dueDate: '2024-10-08', status: 'overdue', days: 2 },
  { customer: 'UD Sejahtera', invoice: 'INV-2024-004', amount: 95000000, dueDate: '2024-10-20', status: 'pending', days: 17 },
  { customer: 'PT Global Tech', invoice: 'INV-2024-005', amount: 106000000, dueDate: '2024-10-25', status: 'pending', days: 22 }
])

// Accounts Payable
const accountsPayable = ref([
  { vendor: 'PT Supplier Utama', invoice: 'BILL-2024-001', amount: 75000000, dueDate: '2024-10-12', status: 'pending', days: 9 },
  { vendor: 'CV Material Indo', invoice: 'BILL-2024-002', amount: 52000000, dueDate: '2024-10-18', status: 'pending', days: 15 },
  { vendor: 'Toko Bahan Baku', invoice: 'BILL-2024-003', amount: 38000000, dueDate: '2024-10-22', status: 'pending', days: 19 },
  { vendor: 'PT Logistik Cepat', invoice: 'BILL-2024-004', amount: 64000000, dueDate: '2024-10-28', status: 'pending', days: 25 },
  { vendor: 'CV Packaging Pro', invoice: 'BILL-2024-005', amount: 60000000, dueDate: '2024-11-05', status: 'pending', days: 33 }
])

// Recent Transactions
const recentTransactions = ref([
  { id: 'TRX-2024-001', type: 'income', description: 'Payment from PT Maju Jaya', amount: 125000000, date: '2024-10-03', category: 'Sales' },
  { id: 'TRX-2024-002', type: 'expense', description: 'Salary Payment - October', amount: 55000000, date: '2024-10-03', category: 'Payroll' },
  { id: 'TRX-2024-003', type: 'income', description: 'Payment from CV Sukses Mandiri', amount: 85000000, date: '2024-10-02', category: 'Sales' },
  { id: 'TRX-2024-004', type: 'expense', description: 'Office Rent - October', amount: 15000000, date: '2024-10-02', category: 'Operational' },
  { id: 'TRX-2024-005', type: 'expense', description: 'Marketing Campaign', amount: 12000000, date: '2024-10-01', category: 'Marketing' },
  { id: 'TRX-2024-006', type: 'income', description: 'Payment from Toko Berkah', amount: 45000000, date: '2024-10-01', category: 'Sales' }
])

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    paid: 'bg-green-100 text-green-800',
    pending: 'bg-yellow-100 text-yellow-800',
    overdue: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-800'
  }
  return colors[status] || 'bg-gray-100 text-gray-800'
}

const getTransactionColor = (type: string) => {
  return type === 'income' ? 'text-green-600' : 'text-red-600'
}

const getTransactionIcon = (type: string) => {
  return type === 'income' ? ArrowDownRight : ArrowUpRight
}
</script>

<template>
  <div class="space-y-6">
    <!-- Header with Date Picker -->
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <Header
          title="Finance Dashboard"
          :subtitle="`${greeting}, ${userName}!`"
          align="left"
      />

      <!-- Date Picker & Button -->
      <div class="flex items-center gap-2">
        <Popover>
          <PopoverTrigger as-child>
            <Button
                variant="outline"
                :class="cn(
                  'w-[230px] justify-start text-left font-normal',
                  !value && 'text-muted-foreground',
                )"
            >
              <CalendarIcon class="mr-2 h-4 w-4" />
              <template v-if="value.start">
                <template v-if="value.end">
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }} - {{ df.format(value.end.toDate(getLocalTimeZone())) }}
                </template>
                <template v-else>
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }}
                </template>
              </template>
              <template v-else>
                Pick a date
              </template>
            </Button>
          </PopoverTrigger>
          <PopoverContent class="w-auto p-0">
            <RangeCalendar
                v-model="value"
                initial-focus
                :number-of-months="2"
                @update:start-value="(startDate) => value.start = startDate"
            />
          </PopoverContent>
        </Popover>

        <!-- Download Report -->
        <Button @click="handleDownloadReport">
          <Download class="mr-2 h-4 w-4" />
          Export Report
        </Button>
      </div>
    </div>

    <!-- Financial KPI Cards -->
    <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card v-for="kpi in financialKpis" :key="kpi.title">
        <CardHeader class="flex flex-row items-center justify-between space-y-0">
          <CardTitle class="text-sm font-medium">{{ kpi.title }}</CardTitle>
          <div :class="[kpi.bgColor, 'p-2 rounded-lg']">
            <component :is="kpi.icon" :class="[kpi.color, 'w-4 h-4']" />
          </div>
        </CardHeader>
        <CardContent>
          <div class="text-xl font-bold">
            {{ kpi.isPercentage ? `${kpi.value}%` : formatCurrency(kpi.value) }}
          </div>
          <div class="flex items-center text-sm">
            <component
                :is="kpi.trend === 'up' ? ArrowUpRight : ArrowDownRight"
                :class="[kpi.trend === 'up' ? 'text-green-600' : 'text-red-600', 'w-4 h-4 mr-1']"
            />
            <span :class="kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'">
              {{ kpi.change }}
            </span>
            <span class="text-muted-foreground ml-1">vs last month</span>
          </div>
        </CardContent>
      </Card>
    </div>

    <!-- Main Charts Row -->
    <div class="grid gap-4 md:grid-cols-7">
      <!-- Cash Flow Chart -->
      <Card class="md:col-span-4">
        <CardHeader>
          <CardTitle>Cash Flow Analysis</CardTitle>
          <CardDescription>Monthly cash inflow, outflow, and net cash flow for 2024</CardDescription>
        </CardHeader>
        <CardContent>
          <VueApexCharts
              type="area"
              height="350"
              :options="cashFlowOptions"
              :series="cashFlowSeries"
          />
        </CardContent>
      </Card>

      <!-- Expense Breakdown -->
      <Card class="md:col-span-3">
        <CardHeader>
          <CardTitle>Expense Breakdown</CardTitle>
          <CardDescription>Distribution of expenses by category</CardDescription>
        </CardHeader>
        <CardContent>
          <VueApexCharts
              type="donut"
              height="320"
              :options="expenseBreakdownOptions"
              :series="expenseBreakdownSeries"
          />
        </CardContent>
      </Card>
    </div>

    <!-- Revenue vs Expense Chart -->
    <Card>
      <CardHeader>
        <CardTitle>Revenue vs Expenses</CardTitle>
        <CardDescription>Monthly comparison of revenue and expenses</CardDescription>
      </CardHeader>
      <CardContent>
        <VueApexCharts
            type="bar"
            height="320"
            :options="revenueExpenseOptions"
            :series="revenueExpenseSeries"
        />
      </CardContent>
    </Card>

    <!-- Accounts Receivable & Payable Row -->
    <div class="grid gap-4 md:grid-cols-2">
      <!-- Accounts Receivable -->
      <Card>
        <CardHeader>
          <div class="flex items-center justify-between">
            <div>
              <CardTitle>Accounts Receivable</CardTitle>
              <CardDescription>Outstanding customer invoices</CardDescription>
            </div>
            <Badge variant="outline" class="text-lg font-semibold">
              {{ formatCurrency(456000000) }}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div class="space-y-3">
            <div
                v-for="ar in accountsReceivable"
                :key="ar.invoice"
                class="flex items-center justify-between p-3 rounded-lg border"
                :class="ar.status === 'overdue' ? 'border-red-200 bg-red-50/30' : ''"
            >
              <div class="space-y-1 flex-1">
                <div class="flex items-center gap-2">
                  <Building2 class="w-4 h-4 text-muted-foreground" />
                  <p class="font-medium">{{ ar.customer }}</p>
                </div>
                <p class="text-sm text-muted-foreground">{{ ar.invoice }}</p>
                <div class="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock class="w-3 h-3" />
                  <span>Due: {{ ar.dueDate }} ({{ ar.days }} days)</span>
                </div>
              </div>
              <div class="text-right space-y-2">
                <p class="font-semibold">{{ formatCurrency(ar.amount) }}</p>
                <Badge :class="getStatusColor(ar.status)" class="capitalize">
                  {{ ar.status }}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <!-- Accounts Payable -->
      <Card>
        <CardHeader>
          <div class="flex items-center justify-between">
            <div>
              <CardTitle>Accounts Payable</CardTitle>
              <CardDescription>Outstanding vendor bills</CardDescription>
            </div>
            <Badge variant="outline" class="text-lg font-semibold">
              {{ formatCurrency(289000000) }}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div class="space-y-3">
            <div
                v-for="ap in accountsPayable"
                :key="ap.invoice"
                class="flex items-center justify-between p-3 rounded-lg border"
            >
              <div class="space-y-1 flex-1">
                <div class="flex items-center gap-2">
                  <Users2 class="w-4 h-4 text-muted-foreground" />
                  <p class="font-medium">{{ ap.vendor }}</p>
                </div>
                <p class="text-sm text-muted-foreground">{{ ap.invoice }}</p>
                <div class="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock class="w-3 h-3" />
                  <span>Due: {{ ap.dueDate }} ({{ ap.days }} days)</span>
                </div>
              </div>
              <div class="text-right space-y-2">
                <p class="font-semibold">{{ formatCurrency(ap.amount) }}</p>
                <Badge :class="getStatusColor(ap.status)" class="capitalize">
                  {{ ap.status }}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>

    <!-- Recent Transactions -->
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
        <CardDescription>Latest financial transactions</CardDescription>
      </CardHeader>
      <CardContent>
        <div class="space-y-3">
          <div
              v-for="transaction in recentTransactions"
              :key="transaction.id"
              class="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
          >
            <div class="flex items-center gap-3 flex-1">
              <div :class="[
                transaction.type === 'income' ? 'bg-green-50' : 'bg-red-50',
                'p-2 rounded-lg'
              ]">
                <component
                    :is="getTransactionIcon(transaction.type)"
                    :class="[getTransactionColor(transaction.type), 'w-4 h-4']"
                />
              </div>
              <div class="flex-1">
                <p class="font-medium">{{ transaction.description }}</p>
                <div class="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                  <span>{{ transaction.id }}</span>
                  <span>•</span>
                  <span>{{ transaction.date }}</span>
                  <span>•</span>
                  <Badge variant="outline" class="text-xs">{{ transaction.category }}</Badge>
                </div>
              </div>
            </div>
            <div class="text-right">
              <p :class="[
                'font-semibold text-lg',
                getTransactionColor(transaction.type)
              ]">
                {{ transaction.type === 'income' ? '+' : '-' }}{{ formatCurrency(transaction.amount) }}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
</template>

<style scoped>

</style>