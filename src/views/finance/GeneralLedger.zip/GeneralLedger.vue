<script setup lang="ts">
import { ref, computed } from 'vue'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Plus,
  Search,
  Filter,
  Download,
  BookOpen,
  Calculator,
  FileText,
  Edit,
  Trash2,
  Eye
} from 'lucide-vue-next'
import Header from "@/components/kakangCustom/Header.vue"
import { useAuthStore } from "@/stores/auth.ts"
import type { DateRange } from "reka-ui"
import type { Ref } from "vue"
import {
  CalendarDate,
  DateFormatter,
  getLocalTimeZone,
} from "@internationalized/date"
import { CalendarIcon } from "lucide-vue-next"
import { cn } from "@/lib/utils"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { RangeCalendar } from "@/components/ui/range-calendar"
import { toast } from "vue-sonner"

// Date Picker Setup
const df = new DateFormatter("en-US", {
  dateStyle: "medium",
})

const value = ref({
  start: new CalendarDate(2024, 10, 1),
  end: new CalendarDate(2024, 10, 31),
}) as Ref<DateRange>

// Auth Store
const authStore = useAuthStore()

const greeting = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good Morning'
  if (hour < 18) return 'Good Afternoon'
  return 'Good Evening'
})

const userName = computed(() => {
  return authStore.userProfile?.displayName || authStore.user?.displayName || 'User'
})

// Format Currency Helper
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value)
}

// Chart of Accounts
const chartOfAccounts = ref([
  { code: '1000', name: 'Cash and Cash Equivalents', type: 'Asset', balance: 1850000000, status: 'active' },
  { code: '1100', name: 'Accounts Receivable', type: 'Asset', balance: 456000000, status: 'active' },
  { code: '1200', name: 'Inventory', type: 'Asset', balance: 680000000, status: 'active' },
  { code: '1300', name: 'Prepaid Expenses', type: 'Asset', balance: 125000000, status: 'active' },
  { code: '1500', name: 'Property, Plant & Equipment', type: 'Asset', balance: 2850000000, status: 'active' },
  { code: '2000', name: 'Accounts Payable', type: 'Liability', balance: 289000000, status: 'active' },
  { code: '2100', name: 'Short-term Debt', type: 'Liability', balance: 180000000, status: 'active' },
  { code: '2200', name: 'Accrued Expenses', type: 'Liability', balance: 145000000, status: 'active' },
  { code: '2500', name: 'Long-term Debt', type: 'Liability', balance: 1250000000, status: 'active' },
  { code: '3000', name: 'Share Capital', type: 'Equity', balance: 2500000000, status: 'active' },
  { code: '3100', name: 'Retained Earnings', type: 'Equity', balance: 982000000, status: 'active' },
  { code: '4000', name: 'Sales Revenue', type: 'Revenue', balance: 2450000000, status: 'active' },
  { code: '4100', name: 'Service Revenue', type: 'Revenue', balance: 320000000, status: 'active' },
  { code: '5000', name: 'Cost of Goods Sold', type: 'Expense', balance: 1470000000, status: 'active' },
  { code: '6000', name: 'Operating Expenses', type: 'Expense', balance: 650000000, status: 'active' },
  { code: '6100', name: 'Salaries and Benefits', type: 'Expense', balance: 520000000, status: 'active' }
])

// Journal Entries
const journalEntries = ref([
  {
    id: 'JE-2024-001',
    date: '2024-10-03',
    reference: 'INV-2024-001',
    description: 'Payment received from PT Maju Jaya',
    entries: [
      { account: '1000', accountName: 'Cash and Cash Equivalents', debit: 125000000, credit: 0 },
      { account: '1100', accountName: 'Accounts Receivable', debit: 0, credit: 125000000 }
    ],
    totalDebit: 125000000,
    totalCredit: 125000000,
    status: 'posted'
  },
  {
    id: 'JE-2024-002',
    date: '2024-10-03',
    reference: 'PAY-2024-010',
    description: 'Monthly salary payment',
    entries: [
      { account: '6100', accountName: 'Salaries and Benefits', debit: 55000000, credit: 0 },
      { account: '1000', accountName: 'Cash and Cash Equivalents', debit: 0, credit: 55000000 }
    ],
    totalDebit: 55000000,
    totalCredit: 55000000,
    status: 'posted'
  },
  {
    id: 'JE-2024-003',
    date: '2024-10-02',
    reference: 'RENT-2024-10',
    description: 'Office rent payment',
    entries: [
      { account: '6000', accountName: 'Operating Expenses', debit: 15000000, credit: 0 },
      { account: '1000', accountName: 'Cash and Cash Equivalents', debit: 0, credit: 15000000 }
    ],
    totalDebit: 15000000,
    totalCredit: 15000000,
    status: 'posted'
  },
  {
    id: 'JE-2024-004',
    date: '2024-10-05',
    reference: 'DRAFT-001',
    description: 'Equipment purchase - pending approval',
    entries: [
      { account: '1500', accountName: 'Property, Plant & Equipment', debit: 85000000, credit: 0 },
      { account: '1000', accountName: 'Cash and Cash Equivalents', debit: 0, credit: 85000000 }
    ],
    totalDebit: 85000000,
    totalCredit: 85000000,
    status: 'draft'
  }
])

// Dialog states
const isAddJournalOpen = ref(false)
const isAddAccountOpen = ref(false)
const selectedJournal = ref(null)

// Form data
const newJournalEntry = ref({
  date: '',
  reference: '',
  description: '',
  entries: [
    { account: '', accountName: '', debit: 0, credit: 0 },
    { account: '', accountName: '', debit: 0, credit: 0 }
  ]
})

const newAccount = ref({
  code: '',
  name: '',
  type: 'Asset',
  status: 'active'
})

// Search and filter
const searchQuery = ref('')
const selectedAccountType = ref('all')
const selectedStatus = ref('all')

// Computed filtered accounts
const filteredAccounts = computed(() => {
  let filtered = chartOfAccounts.value

  if (searchQuery.value) {
    filtered = filtered.filter(account => 
      account.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      account.code.includes(searchQuery.value)
    )
  }

  if (selectedAccountType.value !== 'all') {
    filtered = filtered.filter(account => account.type === selectedAccountType.value)
  }

  if (selectedStatus.value !== 'all') {
    filtered = filtered.filter(account => account.status === selectedStatus.value)
  }

  return filtered
})

// Computed totals
const accountTypeTotals = computed(() => {
  const totals = {
    Asset: 0,
    Liability: 0,
    Equity: 0,
    Revenue: 0,
    Expense: 0
  }

  chartOfAccounts.value.forEach(account => {
    totals[account.type as keyof typeof totals] += account.balance
  })

  return totals
})

// Functions
const addJournalEntry = () => {
  const totalDebit = newJournalEntry.value.entries.reduce((sum, entry) => sum + entry.debit, 0)
  const totalCredit = newJournalEntry.value.entries.reduce((sum, entry) => sum + entry.credit, 0)

  if (totalDebit !== totalCredit) {
    toast.error('Total debits must equal total credits')
    return
  }

  const entry = {
    id: `JE-2024-${String(journalEntries.value.length + 1).padStart(3, '0')}`,
    ...newJournalEntry.value,
    totalDebit,
    totalCredit,
    status: 'draft',
    date: newJournalEntry.value.date || new Date().toISOString().split('T')[0]
  }

  journalEntries.value.unshift(entry)
  
  // Reset form
  newJournalEntry.value = {
    date: '',
    reference: '',
    description: '',
    entries: [
      { account: '', accountName: '', debit: 0, credit: 0 },
      { account: '', accountName: '', debit: 0, credit: 0 }
    ]
  }
  
  isAddJournalOpen.value = false
  toast.success('Journal entry added successfully!')
}

const addAccount = () => {
  const account = {
    ...newAccount.value,
    balance: 0
  }
  
  chartOfAccounts.value.push(account)
  
  // Reset form
  newAccount.value = {
    code: '',
    name: '',
    type: 'Asset',
    status: 'active'
  }
  
  isAddAccountOpen.value = false
  toast.success('Account added successfully!')
}

const addJournalEntryLine = () => {
  newJournalEntry.value.entries.push({ account: '', accountName: '', debit: 0, credit: 0 })
}

const removeJournalEntryLine = (index: number) => {
  if (newJournalEntry.value.entries.length > 2) {
    newJournalEntry.value.entries.splice(index, 1)
  }
}

const getAccountTypeColor = (type: string) => {
  const colors: Record<string, string> = {
    Asset: 'bg-blue-100 text-blue-800',
    Liability: 'bg-red-100 text-red-800',
    Equity: 'bg-purple-100 text-purple-800',
    Revenue: 'bg-green-100 text-green-800',
    Expense: 'bg-orange-100 text-orange-800'
  }
  return colors[type] || 'bg-gray-100 text-gray-800'
}

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    active: 'bg-green-100 text-green-800',
    inactive: 'bg-gray-100 text-gray-800',
    posted: 'bg-blue-100 text-blue-800',
    draft: 'bg-yellow-100 text-yellow-800'
  }
  return colors[status] || 'bg-gray-100 text-gray-800'
}

const exportLedger = () => {
  const toastId = toast.loading('Exporting general ledger...')

  setTimeout(() => {
    toast.success('General ledger exported successfully!', {
      id: toastId,
      duration: 3000
    })
  }, 1500)
}
</script>

<template>
  <div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <Header
          title="General Ledger"
          :subtitle="`${greeting}, ${userName}!`"
          align="left"
      />

      <div class="flex items-center gap-2">
        <Popover>
          <PopoverTrigger as-child>
            <Button
                variant="outline"
                :class="cn(
                  'w-[280px] justify-start text-left font-normal',
                  !value && 'text-muted-foreground',
                )"
            >
              <CalendarIcon class="mr-2 h-4 w-4" />
              <template v-if="value.start">
                <template v-if="value.end">
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }} - {{ df.format(value.end.toDate(getLocalTimeZone())) }}
                </template>
                <template v-else>
                  {{ df.format(value.start.toDate(getLocalTimeZone())) }}
                </template>
              </template>
              <template v-else>
                Select period
              </template>
            </Button>
          </PopoverTrigger>
          <PopoverContent class="w-auto p-0">
            <RangeCalendar
                v-model="value"
                initial-focus
                :number-of-months="2"
                @update:start-value="(startDate) => value.start = startDate"
            />
          </PopoverContent>
        </Popover>

        <Button @click="exportLedger">
          <Download class="mr-2 h-4 w-4" />
          Export
        </Button>

        <Dialog v-model:open="isAddAccountOpen">
          <DialogTrigger as-child>
            <Button variant="outline">
              <Plus class="mr-2 h-4 w-4" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent class="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Account</DialogTitle>
              <DialogDescription>
                Add a new account to the chart of accounts.
              </DialogDescription>
            </DialogHeader>
            <div class="space-y-4">
              <div class="grid grid-cols-2 gap-4">
                <div class="space-y-2">
                  <Label>Account Code</Label>
                  <Input v-model="newAccount.code" placeholder="e.g., 1000" />
                </div>
                <div class="space-y-2">
                  <Label>Account Type</Label>
                  <Select v-model="newAccount.type">
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Asset">Asset</SelectItem>
                      <SelectItem value="Liability">Liability</SelectItem>
                      <SelectItem value="Equity">Equity</SelectItem>
                      <SelectItem value="Revenue">Revenue</SelectItem>
                      <SelectItem value="Expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div class="space-y-2">
                <Label>Account Name</Label>
                <Input v-model="newAccount.name" placeholder="Account name" />
              </div>
              <div class="flex justify-end gap-2">
                <Button variant="outline" @click="isAddAccountOpen = false">Cancel</Button>
                <Button @click="addAccount">Add Account</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog v-model:open="isAddJournalOpen">
          <DialogTrigger as-child>
            <Button>
              <Plus class="mr-2 h-4 w-4" />
              Add Journal Entry
            </Button>
          </DialogTrigger>
          <DialogContent class="sm:max-w-4xl">
            <DialogHeader>
              <DialogTitle>Add Journal Entry</DialogTitle>
              <DialogDescription>
                Create a new journal entry with debits and credits.
              </DialogDescription>
            </DialogHeader>
            <div class="space-y-4">
              <div class="grid grid-cols-3 gap-4">
                <div class="space-y-2">
                  <Label>Date</Label>
                  <Input v-model="newJournalEntry.date" type="date" />
                </div>
                <div class="space-y-2">
                  <Label>Reference</Label>
                  <Input v-model="newJournalEntry.reference" placeholder="Reference number" />
                </div>
                <div class="space-y-2">
                  <Label>Description</Label>
                  <Input v-model="newJournalEntry.description" placeholder="Entry description" />
                </div>
              </div>
              
              <div class="space-y-2">
                <div class="flex items-center justify-between">
                  <Label>Journal Entry Lines</Label>
                  <Button variant="outline" size="sm" @click="addJournalEntryLine">
                    <Plus class="mr-1 h-3 w-3" />
                    Add Line
                  </Button>
                </div>
                
                <div class="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Account</TableHead>
                        <TableHead>Debit</TableHead>
                        <TableHead>Credit</TableHead>
                        <TableHead class="w-12"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow v-for="(entry, index) in newJournalEntry.entries" :key="index">
                        <TableCell>
                          <Select v-model="entry.account">
                            <SelectTrigger>
                              <SelectValue placeholder="Select account" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem 
                                v-for="account in chartOfAccounts" 
                                :key="account.code" 
                                :value="account.code"
                                @click="entry.accountName = account.name"
                              >
                                {{ account.code }} - {{ account.name }}
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Input v-model.number="entry.debit" type="number" placeholder="0" />
                        </TableCell>
                        <TableCell>
                          <Input v-model.number="entry.credit" type="number" placeholder="0" />
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            @click="removeJournalEntryLine(index)"
                            :disabled="newJournalEntry.entries.length <= 2"
                          >
                            <Trash2 class="h-3 w-3" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>
              
              <div class="flex justify-end gap-2">
                <Button variant="outline" @click="isAddJournalOpen = false">Cancel</Button>
                <Button @click="addJournalEntry">Add Entry</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>

    <!-- Account Type Summary -->
    <div class="grid gap-4 md:grid-cols-5">
      <Card v-for="(total, type) in accountTypeTotals" :key="type">
        <CardHeader class="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle class="text-sm font-medium">{{ type }}</CardTitle>
          <BookOpen class="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div class="text-2xl font-bold">{{ formatCurrency(total) }}</div>
        </CardContent>
      </Card>
    </div>

    <!-- Chart of Accounts -->
    <Card>
      <CardHeader>
        <div class="flex items-center justify-between">
          <div>
            <CardTitle>Chart of Accounts</CardTitle>
            <CardDescription>Complete list of all accounts in the general ledger</CardDescription>
          </div>
          <div class="flex items-center gap-2">
            <div class="relative">
              <Search class="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                  v-model="searchQuery"
                  placeholder="Search accounts..."
                  class="pl-8 w-64"
              />
            </div>
            <Select v-model="selectedAccountType">
              <SelectTrigger class="w-32">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Asset">Asset</SelectItem>
                <SelectItem value="Liability">Liability</SelectItem>
                <SelectItem value="Equity">Equity</SelectItem>
                <SelectItem value="Revenue">Revenue</SelectItem>
                <SelectItem value="Expense">Expense</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Account Code</TableHead>
              <TableHead>Account Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Status</TableHead>
              <TableHead class="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow v-for="account in filteredAccounts" :key="account.code">
              <TableCell class="font-mono">{{ account.code }}</TableCell>
              <TableCell class="font-medium">{{ account.name }}</TableCell>
              <TableCell>
                <Badge :class="getAccountTypeColor(account.type)">
                  {{ account.type }}
                </Badge>
              </TableCell>
              <TableCell class="font-semibold">{{ formatCurrency(account.balance) }}</TableCell>
              <TableCell>
                <Badge :class="getStatusColor(account.status)">
                  {{ account.status }}
                </Badge>
              </TableCell>
              <TableCell>
                <Button variant="ghost" size="sm">
                  <Eye class="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>

    <!-- Journal Entries -->
    <Card>
      <CardHeader>
        <CardTitle>Recent Journal Entries</CardTitle>
        <CardDescription>Latest journal entries and transactions</CardDescription>
      </CardHeader>
      <CardContent>
        <div class="space-y-4">
          <div
              v-for="entry in journalEntries"
              :key="entry.id"
              class="border rounded-lg p-4"
          >
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-3">
                <div class="p-2 bg-blue-50 rounded-lg">
                  <FileText class="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p class="font-medium">{{ entry.description }}</p>
                  <div class="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{{ entry.id }}</span>
                    <span>•</span>
                    <span>{{ entry.date }}</span>
                    <span v-if="entry.reference">•</span>
                    <span v-if="entry.reference">{{ entry.reference }}</span>
                  </div>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <Badge :class="getStatusColor(entry.status)">
                  {{ entry.status }}
                </Badge>
                <Button variant="ghost" size="sm">
                  <Edit class="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account</TableHead>
                  <TableHead class="text-right">Debit</TableHead>
                  <TableHead class="text-right">Credit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow v-for="line in entry.entries" :key="line.account">
                  <TableCell>
                    <div>
                      <span class="font-mono text-sm">{{ line.account }}</span>
                      <span class="ml-2">{{ line.accountName }}</span>
                    </div>
                  </TableCell>
                  <TableCell class="text-right">
                    {{ line.debit > 0 ? formatCurrency(line.debit) : '-' }}
                  </TableCell>
                  <TableCell class="text-right">
                    {{ line.credit > 0 ? formatCurrency(line.credit) : '-' }}
                  </TableCell>
                </TableRow>
                <TableRow class="border-t-2">
                  <TableCell class="font-semibold">Total</TableCell>
                  <TableCell class="text-right font-semibold">{{ formatCurrency(entry.totalDebit) }}</TableCell>
                  <TableCell class="text-right font-semibold">{{ formatCurrency(entry.totalCredit) }}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
</template>

<style scoped>

</style>
